import React, { useState, useEffect } from 'react';
import { FaSun, FaMoon, FaBars } from 'react-icons/fa';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import EVRangeEstimator from './components/EVRangeEstimator'; 
import ChargingStations from './components/ChargingStations';
import AboutUs from './components/AboutUs'; 
import ContactUs from './components/ContactUs'; 
import Login from './components/Login';  
import './App.css';
import logo from './logo.svg';

function App() {
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'light');
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  return (
    <Router>
      <div className="container">
        <header className="text-center py-4">
          <Link to="/" className="title-link">
            <img src={logo} className="App-logo" alt="logo" />
            <h1>Charge Route</h1>
          </Link>
          <div className="header-icons">
            <div onClick={toggleTheme} className="theme-toggle-icon">
              {theme === 'light' ? <FaMoon /> : <FaSun />}
            </div>
            <div onClick={toggleMenu} className="menu-toggle-icon">
              <FaBars />
            </div>
            {/* Login Button */}
            <div className="login-button">
              <Link to="/login">
                <button className="login-btn">Login</button>
              </Link>
            </div>
          </div>
        </header>

        {/* Sidebar Menu */}
        <div className={`sidebar ${menuOpen ? 'open' : ''}`}>
          <h2>Menu</h2>
          <ul>
            <li><Link to="/about">About Us</Link></li>
            <li><Link to="/contact">Contact Us</Link></li>
          </ul>
        </div>

        {/* Main Content */}
        <main>
          <Routes>
            <Route path="/" element={
              <>
                <EVRangeEstimator />
                <ChargingStations />
              </>
            } />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/contact" element={<ContactUs />} />
            <Route path="/login" element={<Login />} /> {/* Login route */}
          </Routes>
        </main>

        <footer className="text-center py-3">
          <p>&copy; 2024 Charge Route</p>
        </footer>
      </div>
    </Router>
  );
}

export default App;
