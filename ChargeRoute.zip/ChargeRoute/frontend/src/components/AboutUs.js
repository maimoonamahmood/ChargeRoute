import React from 'react';

const AboutUs = () => {
  return (
    <div>
      <h2>About Us</h2>
      <p>Charge Route is your trusted partner in helping EV owners find nearby charging stations and estimate their vehicle's range accurately. Our mission is to make EV charging accessible and easy for all users.</p>
    </div>
  );
}

export default AboutUs;
