import React, { useEffect, useState } from 'react';

function Login() {
  const [loginHtml, setLoginHtml] = useState('');

  useEffect(() => {
    // Fetch the HTML content for login.html
    fetch('/login.html')
      .then(response => response.text())
      .then(data => setLoginHtml(data));

    // Attach event listeners after the content is loaded
    const handleToggle = (event) => {
      const container = document.getElementById('container');
      if (!container) return;

      if (event.target.id === 'signUp') {
        container.classList.add('right-panel-active');
      } else if (event.target.id === 'signIn') {
        container.classList.remove('right-panel-active');
      }
    };

    document.addEventListener('click', handleToggle);

    // Cleanup event listeners when the component unmounts
    return () => {
      document.removeEventListener('click', handleToggle);
    };
  }, []);

  return (
    <div
      className="login-container"
      dangerouslySetInnerHTML={{ __html: loginHtml }}
    />
  );
}

export default Login;
